================================
Millennial Media SDK for Android
================================

Requirements:
- A Millennial Media APID. (Signup at http://www.mmdev.com)
- Android SDK level 3 or higher

Full documentation and integration instructions are available at:
http://wiki.millennialmedia.com/index.php/Android
